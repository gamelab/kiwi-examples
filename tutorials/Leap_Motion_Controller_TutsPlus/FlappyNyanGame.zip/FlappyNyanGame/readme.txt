Name: Match 3 Blueprint
Version: 1.0
Type: Game
Author: Kiwi.js Team
Website: www.kiwijs.org
KiwiJS last version tested: 0.6

----------------------------------------------------------------------------------------
Versions
----------------------------------------------------------------------------------------

1.0 - Initial Game. 
	

----------------------------------------------------------------------------------------
Description:
----------------------------------------------------------------------------------------
The Match 3 Blueprint is a basic example of a Match 3 game you can use to rapidly build your project and has common Match 3 functionality.

If you have any problems then feel free to contact us via the http://www.kiwijs.org/help