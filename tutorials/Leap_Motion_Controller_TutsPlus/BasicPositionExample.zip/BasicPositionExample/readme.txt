Name: GettingStarted 
Version: 1.0
Type: Game
Author: You
Website: Link to your website

----------------------------------------------------------------------------------------
Versions
----------------------------------------------------------------------------------------

1.0 - Initial Game. 
	

----------------------------------------------------------------------------------------
Description:
----------------------------------------------------------------------------------------
Thanks for using the Kiwi.JS yeoman game generator! If you have any problems, want to view tutorials, or want to just say hi, then visit us on http://www.kiwijs.org/